export interface QueryHistoryDirs {
  localQueriesDirPath: string;
  variantAnalysesDirPath: string;
}
