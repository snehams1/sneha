export enum Mode {
  Application = "application",
  Framework = "framework",
}

export const INITIAL_MODE = Mode.Application;
