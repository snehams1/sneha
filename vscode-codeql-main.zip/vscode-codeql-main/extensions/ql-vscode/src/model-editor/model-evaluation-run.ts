export interface ModelEvaluationRun {
  isPreparing: boolean;
  variantAnalysisId: number | undefined;
}
