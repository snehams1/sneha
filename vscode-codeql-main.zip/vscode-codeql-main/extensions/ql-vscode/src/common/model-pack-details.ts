export interface ModelPackDetails {
  name: string;
  path: string;
}
